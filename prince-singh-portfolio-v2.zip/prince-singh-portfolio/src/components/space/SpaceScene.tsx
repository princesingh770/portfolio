import { Canvas, useFrame } from "@react-three/fiber";
import { Stars, Sparkles, MeshDistortMaterial, Environment, Lightformer } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { spaceState } from "@/lib/space-state";

function glowTexture(color: string) {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  grad.addColorStop(0, color);
  grad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function Core() {
  const group = useRef<THREE.Group>(null);
  const wire = useRef<THREE.Mesh>(null);
  const ring1 = useRef<THREE.Mesh>(null);
  const ring2 = useRef<THREE.Mesh>(null);
  const isMobile = typeof window !== "undefined" && window.innerWidth < 768;
  useFrame((s, d) => {
    const dt = Math.min(d, 0.05);
    const t = s.clock.elapsedTime;
    const g = group.current!;
    const p = spaceState.progress;
    g.rotation.y += dt * 0.25 + spaceState.mx * dt * 0.6;
    g.rotation.x = THREE.MathUtils.damp(g.rotation.x, spaceState.my * 0.4, 3, dt);
    const scale = (1 + Math.sin(t * 2) * 0.03) * (1 - Math.min(p * 3, 0.6));
    g.scale.setScalar(scale);
    g.position.y = (isMobile ? 1.4 : 0) + p * 6;
    wire.current!.rotation.z -= dt * 0.3;
    ring1.current!.rotation.x += dt * 0.6;
    ring2.current!.rotation.y += dt * 0.45;
  });
  return (
    <group ref={group} position={[isMobile ? 0 : 2.6, 0, 0]}>
      <mesh>
        <sphereGeometry args={[1, 64, 64]} />
        <MeshDistortMaterial color="#e8b34b" emissive="#c98a1b" emissiveIntensity={0.8} roughness={0.15} metalness={0.6} distort={0.35} speed={2} />
      </mesh>
      <mesh ref={wire} scale={1.55}>
        <icosahedronGeometry args={[1, 1]} />
        <meshBasicMaterial color="#ffe6a8" wireframe transparent opacity={0.45} />
      </mesh>
      <mesh ref={ring1} rotation={[Math.PI / 2.4, 0, 0]}>
        <torusGeometry args={[2.1, 0.012, 8, 128]} />
        <meshBasicMaterial color="#ffd977" />
      </mesh>
      <mesh ref={ring2} rotation={[0, Math.PI / 3, Math.PI / 5]}>
        <torusGeometry args={[2.5, 0.008, 8, 128]} />
        <meshBasicMaterial color="#fff0c8" />
      </mesh>
      <Sparkles count={60} scale={5} size={3} speed={0.6} color="#ffcf6e" />
    </group>
  );
}

function Nebula() {
  const ref = useRef<THREE.Group>(null);
  const tex = useMemo(
    () => [glowTexture("rgba(255,190,80,0.5)"), glowTexture("rgba(230,160,60,0.35)"), glowTexture("rgba(255,220,140,0.3)")],
    [],
  );
  useFrame((s, d) => {
    ref.current!.rotation.z += Math.min(d, 0.05) * 0.01;
    ref.current!.position.x = Math.sin(s.clock.elapsedTime * 0.05) * 2 + spaceState.progress * -4;
  });
  return (
    <group ref={ref} position={[0, 0, -30]}>
      {([[-12, 6, 40], [14, -8, 50], [0, -2, 36]] as const).map(([x, y, s], i) => (
        <mesh key={i} position={[x, y, -i * 4]}>
          <planeGeometry args={[s, s]} />
          <meshBasicMaterial map={tex[i] ?? null} transparent depthWrite={false} blending={THREE.AdditiveBlending} />
        </mesh>
      ))}
    </group>
  );
}

function Planets() {
  const refs = useRef<THREE.Mesh[]>([]);
  const data: [number, number, number, number, string][] = [
    [-9, 4, -18, 1.6, "#b8862e"],
    [11, -5, -26, 2.6, "#8f7a52"],
    [-6, -9, -34, 1.1, "#c9a44f"],
  ];
  useFrame((s, d) => {
    refs.current.forEach((m, i) => {
      m.rotation.y += Math.min(d, 0.05) * 0.1;
      m.position.y = data[i]![1] + Math.sin(s.clock.elapsedTime * 0.2 + i) * 0.6;
    });
  });
  return (
    <>
      {data.map(([x, y, z, r, c], i) => (
        <mesh key={i} ref={(m) => { if (m) refs.current[i] = m; }} position={[x, y, z]}>
          <sphereGeometry args={[r, 48, 48]} />
          <meshStandardMaterial color={c} roughness={0.7} metalness={0.2} />
        </mesh>
      ))}
    </>
  );
}

function Rig() {
  const stars = useRef<THREE.Group>(null);
  useFrame((s, d) => {
    const dt = Math.min(d, 0.05);
    const p = spaceState.progress;
    const cam = s.camera;
    cam.position.x = THREE.MathUtils.damp(cam.position.x, spaceState.mx * 0.8, 2, dt);
    cam.position.y = THREE.MathUtils.damp(cam.position.y, spaceState.my * 0.5 - p * 2, 2, dt);
    cam.position.z = THREE.MathUtils.damp(cam.position.z, 9 - p * 6, 2, dt);
    cam.lookAt(0, -p * 2, -10);
    stars.current!.rotation.y = p * 1.2 + s.clock.elapsedTime * 0.01;
    stars.current!.rotation.x = p * 0.3;
  });
  return (
    <group ref={stars}>
      <Stars radius={80} depth={60} count={4000} factor={4} saturation={0} fade speed={0.6} />
      <Sparkles count={200} scale={[40, 30, 30]} size={1.6} speed={0.2} opacity={0.5} color="#ffe9b0" />
    </group>
  );
}

export default function SpaceScene() {
  return (
    <Canvas dpr={[1, 1.5]} camera={{ position: [0, 0, 9], fov: 55 }} gl={{ antialias: true, alpha: true }}>
      <ambientLight intensity={0.4} />
      <pointLight position={[6, 4, 6]} intensity={60} color="#ffd489" />
      <directionalLight position={[-5, 5, 5]} intensity={1.2} />
      <Environment resolution={64}>
        <Lightformer intensity={2} position={[0, 5, 0]} scale={[10, 10, 1]} />
        <Lightformer intensity={1} color="#ffcf7a" position={[-5, 1, -1]} rotation-y={Math.PI / 2} scale={[20, 1, 1]} />
      </Environment>
      <Nebula />
      <Planets />
      <Rig />
      <Core />
    </Canvas>
  );
}
