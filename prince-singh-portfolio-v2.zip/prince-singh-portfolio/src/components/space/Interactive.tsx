import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useRef, useState, type ReactNode, type MouseEvent } from "react";
import { cn } from "@/lib/utils";

export function Magnetic({ children, strength = 0.35 }: { children: ReactNode; strength?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useSpring(0, { stiffness: 220, damping: 15 });
  const y = useSpring(0, { stiffness: 220, damping: 15 });
  return (
    <motion.div
      ref={ref}
      style={{ x, y }}
      className="inline-block"
      onMouseMove={(e) => {
        const r = ref.current!.getBoundingClientRect();
        x.set((e.clientX - r.left - r.width / 2) * strength);
        y.set((e.clientY - r.top - r.height / 2) * strength);
      }}
      onMouseLeave={() => { x.set(0); y.set(0); }}
    >
      {children}
    </motion.div>
  );
}

export function GlowButton({ children, onClick, href, variant = "solid", ariaLabel }: { children: ReactNode; onClick?: () => void; href?: string; variant?: "solid" | "ghost"; ariaLabel?: string }) {
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const cls = cn(
    "relative overflow-hidden inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold tracking-wide transition-shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-glow",
    variant === "solid" ? "bg-glow text-ink shadow-[0_0_40px_-8px_var(--glow)]" : "glass",
  );
  const ripple = (e: MouseEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const id = Date.now();
    setRipples((p) => [...p, { id, x: e.clientX - r.left, y: e.clientY - r.top }]);
    setTimeout(() => setRipples((p) => p.filter((q) => q.id !== id)), 700);
    onClick?.();
  };
  const inner = (
    <>
      {ripples.map((r) => (
        <motion.span key={r.id} className="pointer-events-none absolute size-4 rounded-full bg-starlight/60" style={{ left: r.x - 8, top: r.y - 8 }} initial={{ scale: 0, opacity: 0.8 }} animate={{ scale: 14, opacity: 0 }} transition={{ duration: 0.7 }} />
      ))}
      <span className="relative">{children}</span>
    </>
  );
  return (
    <Magnetic>
      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} transition={{ type: "spring", stiffness: 300, damping: 18 }}>
        {href ? (
          <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer" onClick={ripple} className={cls} aria-label={ariaLabel}>{inner}</a>
        ) : (
          <button type="button" onClick={ripple} className={cls} aria-label={ariaLabel}>{inner}</button>
        )}
      </motion.div>
    </Magnetic>
  );
}

export function TiltCard({ children, className }: { children: ReactNode; className?: string }) {
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const rx = useSpring(useTransform(my, [0, 1], [8, -8]), { stiffness: 180, damping: 18 });
  const ry = useSpring(useTransform(mx, [0, 1], [-10, 10]), { stiffness: 180, damping: 18 });
  const gx = useTransform(mx, (v) => `${v * 100}%`);
  const gy = useTransform(my, (v) => `${v * 100}%`);
  const glare = useTransform([gx, gy] as never, ([a, b]: string[]) => `radial-gradient(circle at ${a} ${b}, var(--glow-soft), transparent 60%)`);
  return (
    <motion.div
      data-cursor="card"
      style={{ rotateX: rx, rotateY: ry, transformPerspective: 900 }}
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 200, damping: 20 }}
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        mx.set((e.clientX - r.left) / r.width);
        my.set((e.clientY - r.top) / r.height);
      }}
      onMouseLeave={() => { mx.set(0.5); my.set(0.5); }}
      className={cn("group relative overflow-hidden rounded-3xl glass", className)}
    >
      <motion.div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100" style={{ background: glare }} />
      <div className="relative">{children}</div>
    </motion.div>
  );
}

export function Reveal({ children, delay = 0, className }: { children: ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div className={className} initial={{ opacity: 0, y: 50, filter: "blur(8px)" }} whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }} viewport={{ once: true, margin: "-80px" }} transition={{ type: "spring", stiffness: 70, damping: 18, delay }}>
      {children}
    </motion.div>
  );
}

export function SectionTitle({ kicker, title }: { kicker: string; title: string }) {
  return (
    <Reveal className="mb-12 md:mb-16">
      <p className="font-mono text-xs uppercase tracking-[0.4em] opacity-60">{kicker}</p>
      <h2 className="mt-3 font-display text-4xl font-bold tracking-tight md:text-6xl">{title}</h2>
    </Reveal>
  );
}
