import { motion } from "framer-motion";
import gsap from "gsap";
import { useEffect, useState } from "react";

const LINES = [
  "Initializing neural core…",
  "Calibrating star navigation…",
  "Activating particle field…",
  "Engine ignition sequence…",
  "All systems nominal.",
];

export function Loader({ onDone }: { onDone: () => void }) {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    const o = { v: 0 };
    const tw = gsap.to(o, { v: 100, duration: 2.6, ease: "power2.inOut", onUpdate: () => setPct(Math.round(o.v)), onComplete: () => { setTimeout(onDone, 350); } });
    return () => { tw.kill(); };
  }, [onDone]);
  const shown = Math.min(LINES.length, Math.floor(pct / 20) + 1);
  return (
    <motion.div role="status" aria-label={`Loading ${pct}%`} className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-stage-6 text-starlight" exit={{ opacity: 0, scale: 1.08, filter: "blur(10px)" }} transition={{ duration: 0.9, ease: [0.7, 0, 0.2, 1] }}>
      <div className="relative size-32">
        {[0, 1, 2].map((i) => (
          <motion.div key={i} className="absolute inset-0 rounded-full border border-glow/40" style={{ inset: i * 14 }} animate={{ rotate: i % 2 ? -360 : 360, scale: [1, 1.05, 1] }} transition={{ rotate: { duration: 4 + i * 2, repeat: Infinity, ease: "linear" }, scale: { duration: 2, repeat: Infinity } }} />
        ))}
        <motion.div className="absolute inset-[42px] rounded-full orb-gradient" animate={{ scale: [0.85, 1.1, 0.85] }} transition={{ duration: 1.6, repeat: Infinity }} />
        <span className="absolute inset-0 flex items-center justify-center font-display text-lg font-bold">PS</span>
      </div>
      <p className="mt-10 font-display text-6xl font-bold tabular-nums">{pct}<span className="text-glow">%</span></p>
      <div className="mt-4 h-px w-64 bg-starlight/10">
        <div className="h-px bg-glow shadow-[0_0_12px_var(--glow)]" style={{ width: `${pct}%` }} />
      </div>
      <ul className="mt-6 h-28 w-72 space-y-1 font-mono text-xs text-starlight/60">
        {LINES.slice(0, shown).map((l) => (
          <motion.li key={l} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}>
            <span className="text-glow">▸</span> {l}
          </motion.li>
        ))}
      </ul>
    </motion.div>
  );
}
