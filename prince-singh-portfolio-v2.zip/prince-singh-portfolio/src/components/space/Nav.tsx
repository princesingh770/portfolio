import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { sections } from "@/data/profile";
import { scrollToId } from "@/lib/space-state";
import { cn } from "@/lib/utils";

export function Nav({ dark }: { dark: boolean }) {
  const [active, setActive] = useState<string>("home");
  const [small, setSmall] = useState(false);
  useEffect(() => {
    const onScroll = () => setSmall(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setActive(e.target.id)), { rootMargin: "-45% 0px -50% 0px" });
    sections.forEach((s) => { const el = document.getElementById(s); if (el) io.observe(el); });
    return () => { window.removeEventListener("scroll", onScroll); io.disconnect(); };
  }, []);
  return (
    <motion.nav aria-label="Primary" initial={{ y: -80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ type: "spring", stiffness: 90, damping: 16 }} className={cn("fixed left-1/2 top-4 z-50 -translate-x-1/2 transition-colors duration-700", dark ? "text-starlight" : "text-ink")}>
      <motion.ul layout className={cn("glass flex items-center gap-1 rounded-full", small ? "px-1.5 py-1.5" : "px-3 py-2.5")}>
        <li className="hidden px-3 font-display text-sm font-bold sm:block">PS</li>
        {sections.map((s) => (
          <li key={s} className={cn(s === "certifications" || s === "experience" ? "hidden md:block" : "")}>
            <button onClick={() => scrollToId(s)} aria-current={active === s ? "true" : undefined} className="relative rounded-full px-3 py-1.5 text-xs font-medium capitalize sm:text-sm">
              {active === s && <motion.span layoutId="nav-pill" className="absolute inset-0 rounded-full bg-glow/25" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
              <span className="relative">{s === "certifications" ? "Certs" : s}</span>
            </button>
          </li>
        ))}
      </motion.ul>
    </motion.nav>
  );
}
