import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState, type FormEvent } from "react";
import { FaGithub, FaLinkedin, FaEnvelope, FaPhone, FaMapMarkerAlt, FaRocket, FaExternalLinkAlt, FaCertificate } from "react-icons/fa";
import { profile, stats, skills, projects, timeline, certifications } from "@/data/profile";
import { scrollToId } from "@/lib/space-state";
import { GlowButton, Reveal, SectionTitle, TiltCard } from "./Interactive";
import { cn } from "@/lib/utils";

const wrap = "relative mx-auto w-full max-w-6xl px-5 py-28 md:px-8 md:py-36";

export function Hero() {
  const [i, setI] = useState(0);
  useEffect(() => { const id = setInterval(() => setI((v) => (v + 1) % profile.titles.length), 2200); return () => clearInterval(id); }, []);
  return (
    <section id="home" aria-label="Introduction" className="relative flex min-h-screen items-center text-ink">
      <div className="mx-auto w-full max-w-6xl px-5 pt-40 md:px-8 md:pt-0">
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 0.6 }} transition={{ delay: 0.3 }} className="font-mono text-xs uppercase tracking-[0.4em]">System online · {profile.location}</motion.p>
        <h1 className="mt-6 font-display text-[clamp(3.2rem,11vw,9rem)] font-extrabold leading-[0.9] tracking-tighter">
          {profile.name.split(" ").map((w, wi) => (
            <span key={w} className="block overflow-hidden">
              <motion.span className="block" initial={{ y: "110%" }} animate={{ y: 0 }} transition={{ type: "spring", stiffness: 60, damping: 14, delay: 0.2 + wi * 0.15 }}>{w}</motion.span>
            </span>
          ))}
        </h1>
        <div className="mt-6 h-10 overflow-hidden font-display text-2xl md:text-3xl" aria-live="polite">
          <AnimatePresence mode="wait">
            <motion.p key={i} initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -40, opacity: 0 }} transition={{ type: "spring", stiffness: 120, damping: 16 }} className="text-glow">{profile.titles[i]}</motion.p>
          </AnimatePresence>
        </div>
        <p className="mt-4 max-w-md text-sm opacity-70 md:text-base">{profile.tagline}</p>
        <div className="mt-10 flex flex-wrap gap-3">
          <GlowButton onClick={() => scrollToId("projects")}>View Projects</GlowButton>
          <GlowButton variant="ghost" href={profile.resume}>Download Resume</GlowButton>
          <GlowButton variant="ghost" onClick={() => scrollToId("contact")}>Contact Me</GlowButton>
        </div>
      </div>
      <motion.div aria-hidden className="absolute bottom-8 left-1/2 -translate-x-1/2 font-mono text-[10px] uppercase tracking-[0.4em] opacity-50" animate={{ y: [0, 8, 0] }} transition={{ duration: 2, repeat: Infinity }}>Scroll to launch</motion.div>
    </section>
  );
}

export function About() {
  return (
    <section id="about" aria-label="About" className="text-ink">
      <div className={wrap}>
        <SectionTitle kicker="01 · Pilot profile" title="Hello, I'm Prince." />
        <div className="grid gap-6 md:grid-cols-5">
          <Reveal className="md:col-span-3">
            <TiltCard className="p-8 md:p-10">
              <p className="font-mono text-xs uppercase tracking-widest opacity-60">Biography</p>
              <p className="mt-4 text-lg leading-relaxed md:text-xl">{profile.about}</p>
              <div className="mt-8 flex flex-wrap gap-2 text-xs">
                {[profile.education.college, profile.education.degree, profile.education.year].map((t) => <span key={t} className="glass rounded-full px-3 py-1">{t}</span>)}
              </div>
            </TiltCard>
          </Reveal>
          <div className="grid grid-cols-2 gap-4 md:col-span-2">
            {stats.map((s, k) => (
              <Reveal key={s.label} delay={k * 0.08}>
                <TiltCard className="flex h-full flex-col justify-between p-6">
                  <p className="font-display text-4xl font-bold">{s.value}</p>
                  <p className="mt-6 text-xs uppercase tracking-widest opacity-60">{s.label}</p>
                </TiltCard>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Skills() {
  const [sel, setSel] = useState(0);
  const s = skills[sel] ?? skills[0]!;
  return (
    <section id="skills" aria-label="Skills" className="text-starlight">
      <div className={wrap}>
        <SectionTitle kicker="02 · Skill system" title="A galaxy of skills." />
        <div className="grid items-center gap-10 lg:grid-cols-[1.4fr_1fr]">
          <div className="grid grid-cols-2 gap-x-4 gap-y-10 sm:grid-cols-4">
            {skills.map((sk, k) => (
              <motion.button
                key={sk.name}
                onMouseEnter={() => setSel(k)}
                onFocus={() => setSel(k)}
                onClick={() => setSel(k)}
                aria-label={sk.name}
                className="group relative mx-auto flex flex-col items-center"
                animate={{ y: [0, k % 2 ? 10 : -10, 0] }}
                transition={{ duration: 4 + (k % 3), repeat: Infinity, ease: "easeInOut" }}
              >
                <motion.div whileHover={{ scale: 1.15 }} transition={{ type: "spring", stiffness: 260, damping: 14 }} className={cn("planet relative flex items-center justify-center rounded-full font-display text-sm font-bold text-ink", k % 3 === 0 ? "size-24" : k % 3 === 1 ? "size-20" : "size-16")}>
                  {sk.short}
                  <motion.div className="absolute -inset-4" animate={{ rotate: 360 }} transition={{ duration: 6 + k, repeat: Infinity, ease: "linear" }}>
                    <span className="absolute left-0 top-1/2 size-1.5 rounded-full bg-starlight shadow-[0_0_8px_var(--glow)]" />
                    <span className="absolute right-2 top-2 size-1 rounded-full bg-glow" />
                  </motion.div>
                  {sel === k && <motion.div layoutId="planet-ring" className="absolute -inset-3 rounded-full border border-glow" />}
                </motion.div>
                <span className="mt-4 text-center text-xs opacity-70">{sk.name}</span>
              </motion.button>
            ))}
          </div>
          <AnimatePresence mode="wait">
            <motion.div key={s.name} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ type: "spring", stiffness: 120, damping: 18 }} className="glass rounded-3xl p-8" aria-live="polite">
              <p className="font-mono text-xs uppercase tracking-widest text-glow">Planet scan</p>
              <h3 className="mt-3 font-display text-3xl font-bold">{s.name}</h3>
              <p className="mt-4 opacity-80">{s.desc}</p>
              <dl className="mt-6 grid grid-cols-2 gap-4 text-sm">
                <div><dt className="opacity-50">Experience</dt><dd className="mt-1">{s.exp}</dd></div>
                <div><dt className="opacity-50">Projects</dt><dd className="mt-1">Coursework & practice</dd></div>
              </dl>
              <div className="mt-6 flex flex-wrap gap-2">{s.stack.map((t) => <span key={t} className="rounded-full bg-glow/15 px-3 py-1 text-xs">{t}</span>)}</div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

export function Projects() {
  return (
    <section id="projects" aria-label="Projects" className="text-starlight">
      <div className={wrap}>
        <SectionTitle kicker="03 · Missions" title="Selected projects." />
        <div className="grid gap-6 md:grid-cols-2">
          {projects.map((p, k) => (
            <Reveal key={p.name} delay={k * 0.1} className={k === 0 ? "md:col-span-2" : ""}>
              <TiltCard className={cn("h-full p-8", k === 0 && "md:grid md:grid-cols-2 md:gap-10 md:p-10")}>
                <div className={cn("relative mb-6 aspect-video overflow-hidden rounded-2xl bg-stage-5", k === 0 && "md:mb-0")}>
                  <motion.div className="absolute inset-0 orb-gradient opacity-60" animate={{ scale: [1, 1.2, 1], x: ["-10%", "10%", "-10%"] }} transition={{ duration: 10 + k * 2, repeat: Infinity }} />
                  <motion.div className="absolute inset-0 flex items-center justify-center font-display text-5xl font-extrabold opacity-90" whileHover={{ scale: 1.08 }}>{p.name.split(" ").map((w) => w[0]).join("")}</motion.div>
                  {k === 0 && <span className="absolute left-4 top-4 rounded-full bg-glow px-3 py-1 text-xs font-semibold text-stage-6">Featured</span>}
                </div>
                <div className="flex flex-col">
                  <p className="font-mono text-xs opacity-50">Mission 0{k + 1}</p>
                  <h3 className="mt-2 font-display text-2xl font-bold md:text-3xl">{p.name}</h3>
                  <p className="mt-3 opacity-75">{p.desc}</p>
                  <div className="mt-5 flex flex-wrap gap-2">{p.stack.map((t) => <span key={t} className="rounded-full bg-glow/15 px-3 py-1 text-xs">{t}</span>)}</div>
                  <div className="mt-6 flex gap-5 text-sm">
                    <a href={p.github} className="inline-flex items-center gap-2 hover:text-glow" aria-label={`${p.name} on GitHub`}><FaGithub /> GitHub</a>
                    <a href={p.live} className="inline-flex items-center gap-2 hover:text-glow" aria-label={`${p.name} live demo`}><FaExternalLinkAlt /> Live demo</a>
                  </div>
                </div>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Experience() {
  return (
    <section id="experience" aria-label="Journey" className="text-starlight">
      <div className={wrap}>
        <SectionTitle kicker="04 · Flight log" title="The journey so far." />
        <ol className="relative ml-3 border-l border-glow/30 md:ml-6">
          {timeline.map((t, k) => (
            <motion.li key={t.title} className="relative mb-12 pl-8 md:pl-12" initial={{ opacity: 0, x: -40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, margin: "-80px" }} transition={{ type: "spring", stiffness: 70, damping: 16, delay: k * 0.1 }}>
              <motion.span className="absolute -left-[7px] top-2 size-3 rounded-full bg-glow shadow-[0_0_16px_var(--glow)]" animate={{ scale: [1, 1.5, 1] }} transition={{ duration: 2, repeat: Infinity, delay: k * 0.4 }} />
              <TiltCard className="p-6 md:p-8">
                <p className="font-mono text-xs text-glow">{t.when}</p>
                <h3 className="mt-2 font-display text-xl font-bold md:text-2xl">{t.title}</h3>
                <p className="text-sm opacity-60">{t.where}</p>
                <p className="mt-3 opacity-80">{t.desc}</p>
              </TiltCard>
            </motion.li>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function Certifications() {
  return (
    <section id="certifications" aria-label="Certifications" className="text-starlight">
      <div className={wrap}>
        <SectionTitle kicker="05 · Credentials" title="Certifications." />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {certifications.map((c, k) => (
            <Reveal key={c} delay={k * 0.06}>
              <TiltCard className="flex items-center gap-4 p-6">
                <motion.span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-glow/15 text-glow" whileHover={{ rotate: 180 }} transition={{ type: "spring", stiffness: 200 }}><FaCertificate /></motion.span>
                <div><h3 className="font-semibold">{c}</h3><p className="text-xs opacity-60">Professional certificate</p></div>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Contact() {
  const [launched, setLaunched] = useState(false);
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setLaunched(true);
    const body = encodeURIComponent(`${f.get("message")}\n\n— ${f.get("name")} (${f.get("email")})`);
    setTimeout(() => { window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent("Hello from your portfolio")}&body=${body}`; }, 900);
    setTimeout(() => setLaunched(false), 2600);
  };
  const field = "w-full rounded-2xl bg-starlight/5 border border-starlight/15 px-4 py-3 text-sm outline-none transition focus:border-glow focus:shadow-[0_0_0_4px_var(--glow-soft)] placeholder:text-starlight/40";
  return (
    <section id="contact" aria-label="Contact" className="text-starlight">
      <div className={wrap}>
        <SectionTitle kicker="06 · Mission control" title="Let's build something." />
        <div className="grid gap-8 lg:grid-cols-[1fr_1.3fr]">
          <Reveal className="space-y-4">
            {[
              { icon: <FaEnvelope />, label: profile.email, href: `mailto:${profile.email}` },
              { icon: <FaPhone />, label: profile.phone, href: "tel:+918000172200" },
              { icon: <FaMapMarkerAlt />, label: profile.location },
              { icon: <FaLinkedin />, label: "princechaudhary0707", href: profile.linkedin },
            ].map((c) => (
              <motion.a key={c.label} href={c.href} target={c.href?.startsWith("http") ? "_blank" : undefined} rel="noreferrer" whileHover={{ x: 8 }} className="glass flex items-center gap-4 rounded-2xl p-4 break-all text-sm">
                <span className="text-glow">{c.icon}</span>{c.label}
              </motion.a>
            ))}
          </Reveal>
          <Reveal delay={0.1}>
            <form onSubmit={submit} className="glass space-y-4 rounded-3xl p-6 md:p-8" aria-label="Contact form">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block"><span className="sr-only">Name</span><input required name="name" placeholder="Your name" className={field} /></label>
                <label className="block"><span className="sr-only">Email</span><input required type="email" name="email" placeholder="Your email" className={field} /></label>
              </div>
              <label className="block"><span className="sr-only">Message</span><textarea required name="message" rows={5} placeholder="Transmit your message…" className={field} /></label>
              <motion.button type="submit" whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.96 }} className="relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-glow px-7 py-3 font-semibold text-stage-6">
                <motion.span animate={launched ? { x: 160, y: -120, rotate: -45, opacity: 0 } : { x: 0, y: 0, rotate: 0, opacity: 1 }} transition={{ type: "spring", stiffness: 60, damping: 12 }}><FaRocket /></motion.span>
                {launched ? "Launching…" : "Send transmission"}
              </motion.button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

const STARS: [number, number][] = [[10, 40], [22, 20], [35, 35], [48, 15], [60, 30], [72, 12], [85, 38]];

export function Footer() {
  return (
    <footer className="relative overflow-hidden text-starlight">
      <svg aria-hidden viewBox="0 0 100 50" className="mx-auto h-40 w-full max-w-4xl opacity-70">
        <motion.polyline points={STARS.map((p) => p.join(",")).join(" ")} fill="none" stroke="var(--glow)" strokeWidth="0.2" initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} transition={{ duration: 3 }} viewport={{ once: true }} />
        {STARS.map(([x, y], k) => <motion.circle key={k} cx={x} cy={y} r="0.7" fill="var(--starlight)" animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 2 + k * 0.3, repeat: Infinity }} />)}
      </svg>
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 px-5 pb-12 md:flex-row md:px-8">
        <p className="text-sm opacity-60">© {new Date().getFullYear()} {profile.name} · Drifting through deep space.</p>
        <div className="flex gap-5 text-xl">
          {[{ i: <FaLinkedin />, h: profile.linkedin, l: "LinkedIn" }, { i: <FaEnvelope />, h: `mailto:${profile.email}`, l: "Email" }].map((s) => (
            <motion.a key={s.l} href={s.h} aria-label={s.l} target="_blank" rel="noreferrer" whileHover={{ rotate: 15, scale: 1.2 }} className="hover:text-glow">{s.i}</motion.a>
          ))}
        </div>
      </div>
    </footer>
  );
}
