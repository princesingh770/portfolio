import { motion, useMotionValue, useSpring } from "framer-motion";
import { useEffect, useState } from "react";

const TRAIL = [0, 1, 2, 3, 4, 5];

function TrailDot({ x, y, i }: { x: ReturnType<typeof useMotionValue<number>>; y: ReturnType<typeof useMotionValue<number>>; i: number }) {
  const sx = useSpring(x, { stiffness: 300 - i * 40, damping: 22 + i * 2 });
  const sy = useSpring(y, { stiffness: 300 - i * 40, damping: 22 + i * 2 });
  const size = 8 - i;
  return <motion.div aria-hidden className="pointer-events-none fixed left-0 top-0 z-[100] rounded-full bg-glow blur-[1px]" style={{ x: sx, y: sy, width: size, height: size, marginLeft: -size / 2, marginTop: -size / 2, opacity: 0.5 - i * 0.07 }} />;
}

export function Cursor() {
  const [enabled, setEnabled] = useState(false);
  const [mode, setMode] = useState<"idle" | "hover" | "card">("idle");
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 500, damping: 28, mass: 0.6 });
  const sy = useSpring(y, { stiffness: 500, damping: 28, mass: 0.6 });

  useEffect(() => {
    const fine = window.matchMedia("(pointer: fine)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduced) return;
    setEnabled(true);
    document.documentElement.classList.add("has-orb");
    const move = (e: PointerEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      const t = e.target as HTMLElement;
      if (t.closest?.("a,button,input,textarea,[role=button]")) setMode("hover");
      else if (t.closest?.("[data-cursor=card]")) setMode("card");
      else setMode("idle");
    };
    window.addEventListener("pointermove", move);
    return () => {
      window.removeEventListener("pointermove", move);
      document.documentElement.classList.remove("has-orb");
    };
  }, [x, y]);

  if (!enabled) return null;
  const size = mode === "hover" ? 64 : mode === "card" ? 44 : 22;
  return (
    <>
      {TRAIL.map((i) => <TrailDot key={i} x={x} y={y} i={i} />)}
      <motion.div aria-hidden className="pointer-events-none fixed left-0 top-0 z-[101]" style={{ x: sx, y: sy }}>
        <motion.div
          className="relative -translate-x-1/2 -translate-y-1/2 rounded-full orb-gradient mix-blend-difference"
          animate={{ width: size, height: size, opacity: mode === "hover" ? 0.7 : 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
        >
          <motion.div className="absolute inset-[-10px]" animate={{ rotate: 360 }} transition={{ duration: 3, repeat: Infinity, ease: "linear" }}>
            <span className="absolute left-1/2 top-0 size-1.5 rounded-full bg-glow" />
            <span className="absolute bottom-0 left-1/2 size-1 rounded-full bg-starlight" />
          </motion.div>
        </motion.div>
      </motion.div>
    </>
  );
}
