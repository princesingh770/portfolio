export const profile = {
  name: "Prince Singh",
  tagline: "AI Engineer · Learning Full Stack Developer · ML Enthusiast",
  email: "princesinghchaudhary77@gmail.com",
  phone: "+91 8000172200",
  location: "Jaipur, Rajasthan",
  linkedin: "https://www.linkedin.com/in/princechaudhary0707",
  resume: "https://www.linkedin.com/in/princechaudhary0707",
  about:
    "Computer Science Engineering student at JECRC University, passionate about technology, coding, and problem-solving. Skilled in Python and eager to explore Data Science, Web Development, and Software Engineering. Enthusiastic about learning, collaborating, and contributing to innovative projects.",
  titles: ["AI Engineer", "Full Stack Developer", "ML Engineer", "Backend Developer", "Creator", "Builder"],
  education: { college: "JECRC University", degree: "B.Tech CSE", year: "2nd Year", cgpa: "8.0" },
};

export const stats = [
  { value: "8.0", label: "CGPA" },
  { value: "7+", label: "AI & business skills" },
  { value: "2nd", label: "Year, B.Tech CSE" },
  { value: "∞", label: "Curiosity" },
];

export const skills = [
  { name: "Artificial Intelligence", short: "AI", desc: "Core concepts of machine learning, models and responsible AI.", exp: "Learning · 1 yr", stack: ["Python", "ML basics", "Prompting"] },
  { name: "AI for Business", short: "AIB", desc: "Applying AI to real business problems and workflows.", exp: "Certified track", stack: ["Strategy", "Automation", "Analytics"] },
  { name: "Generative AI for Sales", short: "GEN", desc: "Using generative AI to research, pitch and close faster.", exp: "Certified track", stack: ["LLMs", "Copilot", "CRM"] },
  { name: "Microsoft Copilot", short: "CP", desc: "Boosting productivity across Office with Copilot.", exp: "Hands-on", stack: ["Word", "Excel", "Teams"] },
  { name: "Customer Journey Mapping", short: "CJM", desc: "Mapping touchpoints to design better experiences.", exp: "Certified track", stack: ["Research", "Personas", "UX"] },
  { name: "Customer Service Mgmt", short: "CSM", desc: "Building service processes customers love.", exp: "Certified track", stack: ["Support ops", "Empathy", "KPIs"] },
  { name: "Digital Marketing", short: "DM", desc: "Reaching audiences through content, SEO and social.", exp: "Certified track", stack: ["SEO", "Social", "Content"] },
  { name: "Python", short: "PY", desc: "My primary language for scripts, data and problem-solving.", exp: "1+ yr", stack: ["Python", "Pandas", "DSA"] },
];

// Sample projects — replace with real ones.
export const projects = [
  { name: "Nebula Assistant", desc: "An AI study companion that summarises notes and generates quizzes using large language models.", stack: ["Python", "OpenAI", "Streamlit"], github: "#", live: "#" },
  { name: "Journey Mapper", desc: "Interactive tool for mapping customer journeys with AI-suggested pain points and fixes.", stack: ["React", "TypeScript", "AI"], github: "#", live: "#" },
  { name: "Campus Pulse", desc: "Data dashboard visualising campus event engagement with Python analytics.", stack: ["Python", "Pandas", "Charts"], github: "#", live: "#" },
];

export const timeline = [
  { when: "2024", title: "Joined JECRC University", where: "B.Tech Computer Science", desc: "Started engineering journey; fell in love with Python and problem-solving." },
  { when: "2025", title: "AI & Business Certifications", where: "Self-driven learning", desc: "Completed tracks in AI for Business, Generative AI for Sales, Copilot and more." },
  { when: "Now", title: "2nd Year · CGPA 8.0", where: "JECRC University", desc: "Exploring Data Science, Web Development and Software Engineering by building." },
];

export const certifications = [
  "AI for Business",
  "Generative AI for Sales",
  "Microsoft Copilot",
  "Customer Journey Mapping",
  "Customer Service Management",
  "Digital Marketing",
];

export const sections = ["home", "about", "skills", "projects", "experience", "certifications", "contact"] as const;
