import type Lenis from "lenis";

/** Shared mutable state read inside the 3D render loop (avoids React re-renders). */
export const spaceState = { mx: 0, my: 0, progress: 0 };
export const lenisRef: { current: Lenis | null } = { current: null };

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  if (lenisRef.current) lenisRef.current.scrollTo(el, { offset: -20, duration: 1.6 });
  else el.scrollIntoView({ behavior: "smooth" });
}
