import { createFileRoute, ClientOnly } from "@tanstack/react-router";
import { AnimatePresence, motion, useScroll, useTransform, useMotionValueEvent } from "framer-motion";
import Lenis from "lenis";
import { lazy, Suspense, useCallback, useEffect, useState } from "react";
import { Loader } from "@/components/space/Loader";
import { Cursor } from "@/components/space/Cursor";
import { Nav } from "@/components/space/Nav";
import { Hero, About, Skills, Projects, Experience, Certifications, Contact, Footer } from "@/components/space/Sections";
import { lenisRef, spaceState } from "@/lib/space-state";

const SpaceScene = lazy(() => import("@/components/space/SpaceScene"));

const TITLE = "Prince Singh — AI Engineer & Developer Portfolio";
const DESC = "Prince Singh, B.Tech CSE student at JECRC University, Jaipur. AI engineer in the making, exploring ML, full stack and generative AI.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESC },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: "Prince Singh",
          jobTitle: "AI Engineer",
          email: "mailto:princesinghchaudhary77@gmail.com",
          address: { "@type": "PostalAddress", addressLocality: "Jaipur", addressRegion: "Rajasthan", addressCountry: "IN" },
          alumniOf: "JECRC University",
          sameAs: ["https://www.linkedin.com/in/princechaudhary0707"],
        }),
      },
    ],
  }),
  component: Index,
});

const STAGES = ["bg-stage-2", "bg-stage-3", "bg-stage-4", "bg-stage-5", "bg-stage-6"];

function StageLayer({ cls, i, progress }: { cls: string; i: number; progress: ReturnType<typeof useScroll>["scrollYProgress"] }) {
  const start = [0.06, 0.2, 0.36, 0.55, 0.75][i] ?? 0;
  const opacity = useTransform(progress, [start, start + 0.12], [0, 1]);
  return <motion.div aria-hidden className={`fixed inset-0 ${cls}`} style={{ opacity }} />;
}

function Index() {
  const [loading, setLoading] = useState(true);
  const [dark, setDark] = useState(false);
  const { scrollYProgress } = useScroll();
  const done = useCallback(() => setLoading(false), []);

  useMotionValueEvent(scrollYProgress, "change", (v) => {
    spaceState.progress = v;
    setDark(v > 0.22);
  });

  useEffect(() => {
    const move = (e: PointerEvent) => {
      spaceState.mx = (e.clientX / window.innerWidth) * 2 - 1;
      spaceState.my = -((e.clientY / window.innerHeight) * 2 - 1);
    };
    window.addEventListener("pointermove", move);
    let lenis: Lenis | null = null;
    let raf = 0;
    if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      lenis = new Lenis({ lerp: 0.08, wheelMultiplier: 0.9 });
      lenisRef.current = lenis;
      const loop = (t: number) => { lenis!.raf(t); raf = requestAnimationFrame(loop); };
      raf = requestAnimationFrame(loop);
    }
    return () => { window.removeEventListener("pointermove", move); cancelAnimationFrame(raf); lenis?.destroy(); lenisRef.current = null; };
  }, []);

  return (
    <>
      <AnimatePresence>{loading && <Loader key="loader" onDone={done} />}</AnimatePresence>
      <div aria-hidden className="fixed inset-0 bg-stage-1" />
      {STAGES.map((c, i) => <StageLayer key={c} cls={c} i={i} progress={scrollYProgress} />)}
      <div aria-hidden className="pointer-events-none fixed inset-0">
        <ClientOnly fallback={null}>
          <Suspense fallback={null}><SpaceScene /></Suspense>
        </ClientOnly>
      </div>
      <ClientOnly fallback={null}><Cursor /></ClientOnly>
      <Nav dark={dark} />
      <main className="relative z-10">
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Experience />
        <Certifications />
        <Contact />
      </main>
      <div className="relative z-10"><Footer /></div>
    </>
  );
}
